/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.dbconnecttest;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author line
 */
public class JavaCon {
    Connection conn=null;
    
   public static Connection dbConnector(){
    try{  
    Class.forName("com.mysql.jdbc.Driver");  
    Connection con=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/jdbctest?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");  

    //Statement stmt=con.createStatement();  
    //ResultSet rs=stmt.executeQuery("select * from user");  
    //while(rs.next())  
    //System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));  
    //JOptionPane.showMessageDialog(null,"Connection Succesful");
    //con.close();
    
     return con;
    }
    catch(Exception e){ 
        System.out.println(e);
         return null;
    }  
   }  
}
